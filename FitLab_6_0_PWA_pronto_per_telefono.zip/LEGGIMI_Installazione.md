# FitLab PWA — guida di installazione

Questa cartella contiene **FitLab 6.0** pronto per essere pubblicato su GitHub Pages e installato sulla schermata Home di Android o iPhone.

## 1. Pubblica il sito (dal computer)

1. Vai su https://github.com e accedi (o crea un account gratuito).
2. Clicca **New repository** e chiamalo `fitlab`.
3. Seleziona **Public** e crea il repository.
4. Clicca **Add file → Upload files**.
5. Trascina **il contenuto estratto dalla cartella FitLab_PWA**, non il file ZIP: `index.html`, `manifest.webmanifest`, `service-worker.js`, `.nojekyll` e la cartella `icons` con i tre PNG. Se il browser non permette di trascinare la cartella, trascina tutti i file mantenendo i percorsi. Controlla che `icons/icon-192.png`, `icons/icon-512.png`, `icons/apple-touch-icon.png` risultino presenti nella cartella `icons` del repository.
6. Premi **Commit changes**.
7. Apri **Settings → Pages**, scegli **Deploy from a branch**, `main`, `/(root)` e **Save**.
8. Torna in **Settings → Pages**: lì apparirà l'indirizzo del sito dopo la pubblicazione, simile a `https://TUONOME.github.io/fitlab/`.

## 2. Installa sul telefono

**Android, Chrome**: apri il link HTTPS → menu `⋮` → **Installa app** (o **Aggiungi a schermata Home**).

**iPhone, Safari**: apri il link HTTPS → Condividi → **Aggiungi alla schermata Home** → abilita **Apri come app web** se presente → **Aggiungi**.

## 3. Uso e avvertenze

- Apri la PWA online almeno una volta per attivare la cache; in seguito funziona offline sullo stesso dispositivo.
- L'app salva allenamenti, alimenti e misurazioni **solo nel browser/dispositivo dove li inserisci** (localStorage). Non c'è sincronizzazione automatica tra PC e smartphone.
- Pubblicare il codice in un repository Public **non pubblica i tuoi diari**: quelli vengono inseriti solo nel browser. Non aggiungere mai dati personali o file di backup al repository.
- Se cancelli dati del sito o browser potresti perdere i registri. Questa versione non ha un account cloud e non è una soluzione di backup.
- Se in precedenza usavi il file HTML locale, i dati di quel file **non saranno trasferiti automaticamente** al sito GitHub Pages.
- La cartella va pubblicata su HTTPS; aprire `index.html` dal telefono come file locale non abilita l'installazione PWA completa.

**Nota**: non è necessario pagare né usare App Store/Play Store. Il sito rimane pubblico: chiunque abbia il link può usare la propria istanza locale di FitLab.
